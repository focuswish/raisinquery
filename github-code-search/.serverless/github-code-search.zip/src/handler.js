"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const tools = require("dynamodb-tools");
const repos_1 = require("./repos");
const empty = require("lodash.isempty");
const util_1 = require("./util");
const slugify_1 = require("slugify");
function initialFetch({ query, repoIndex }) {
    return __awaiter(this, void 0, void 0, function* () {
        let repo = repos_1.default.items[repoIndex];
        util_1.log(['repo', repo]);
        let { full_name } = repo;
        let q = encodeURIComponent(query);
        let url = `https://api.github.com/search/code?q=${q}+in:file+language:js+repo:${full_name}`;
        return util_1.get(url, {
            headers: {
                Accept: "application/vnd.github.v3.text-match+json"
            }
        });
    });
}
function createSnippets(props) {
    util_1.log(['createSnippet', props]);
    let { content, matches } = props;
    let decoded = util_1.atob(content).split("\n");
    util_1.log(['createSnippet', decoded]);
    let text = matches[0].text;
    return decoded.reduce((acc, val, i, arr) => {
        if (val.indexOf(text) > -1) {
            let message = util_1.innerContents(arr.slice(i, i + 2).join(''));
            console.log('message', message);
            let { lines, startIndex } = util_1.getCodeSegment(i, arr);
            if (message) {
                acc.push({
                    index: i,
                    startIndex,
                    lines,
                    message
                });
            }
        }
        return acc;
    }, []);
}
function default_1() {
    return __awaiter(this, void 0, void 0, function* () {
        let store = yield util_1.getState();
        let query = 'throw new error';
        let searchResults = yield initialFetch({
            query,
            repoIndex: store.repo_index
        });
        if (empty(searchResults.items) ||
            searchResults.items.length < 1) {
            store.repo_index++;
            store.search_index = 0;
        }
        if (empty(searchResults.items)) {
            util_1.setState({ store });
            return;
        }
        process.env.REPO_INDEX = store.repo_index;
        let item = searchResults.items[store.search_index];
        util_1.log(['item', item]);
        let { repository } = item;
        let { owner } = repository;
        let { object_url: objectUrl, matches } = item.text_matches[0];
        let code = yield util_1.get(objectUrl);
        store.search_index++;
        util_1.log(['code', code]);
        let { content, html_url: htmlUrl } = code;
        let snippets = createSnippets({
            content,
            matches,
        });
        util_1.log(['snippets', snippets]);
        if (!snippets || snippets.length === 0) {
            return util_1.setState({ store });
        }
        let { name: repoName, id: repoId } = repository;
        snippets.forEach(snippet => {
            let message = snippet.message.toLowerCase();
            let id = repoName + '/' + slugify_1.default(message);
            //remove: /[$*_+~.()'"!\-:@]/g
            let input = Object.assign({}, snippet, { id,
                repoName,
                repoId,
                objectUrl,
                htmlUrl,
                query });
            tools.create("posts", { input });
        });
        util_1.setState({ store });
    });
}
exports.default = default_1;
//# sourceMappingURL=handler.js.map