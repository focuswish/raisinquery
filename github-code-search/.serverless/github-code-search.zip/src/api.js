"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const tools = require("dynamodb-tools");
const createResponse = (message = {}) => ({
    statusCode: 200,
    body: JSON.stringify(message),
    headers: {
        'Access-Control-Allow-Origin': '*',
    },
});
exports.default = (event, context, callback) => __awaiter(this, void 0, void 0, function* () {
    let { queryStringParameters } = event;
    let { id, all } = queryStringParameters;
    const TableName = `${process.env.DYNAMODB_TABLE}-posts`;
    if (all) {
        let posts = yield tools.db.scan({ TableName });
        console.log(posts);
        return callback(null, createResponse(posts));
    }
    tools.getById('posts', id).then(data => {
        console.log(data);
        callback(null, createResponse(data));
    }).catch(message => {
        callback(null, createResponse(Object.assign({}, message, { error: true })));
    });
});
//# sourceMappingURL=api.js.map